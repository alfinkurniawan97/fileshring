<?php include("config.php"); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
 <title>Website Upload dan Download</title>
  <link href="css/bootstrap.min.css" rel="stylesheet">

  <style type="text/css">
    body {
      padding-top: 10px;
      background: #00ff99;

    }

    .container-body {
      background: #3399ff;
      box-shadow: 1px 1px 1px #3399ff;
      padding: 40px;
width: 100%;
height: 100%;
margin-right: 25px;
    }
  </style>

  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
</head>
<body>



  <div class="container container-body">
    <h1>upload terbaru</h1>
    <hr>
    <?php
      if(!$_SESSION['user']){ echo 'anda belum login';
}else{
      echo "hellow worldx";
    ?>

    

   
    <hr>
    <center>copyright &copy; 2019 <a href="http://sshgass.xyz/" target="_blank">ssh gass</a></center>
  </div>

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
</body>
</html>
